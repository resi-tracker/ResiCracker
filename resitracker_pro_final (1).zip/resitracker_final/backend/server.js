// Express proxy to BinderByte API
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
require('dotenv').config();
const app = express();
app.use(cors());
app.use(express.json());

const API_KEY = process.env.BINDERBYTE_API_KEY;
if(!API_KEY) console.warn('BINDERBYTE_API_KEY not set in .env');

app.post('/api/track', async (req, res) => {
  try {
    const { courier, awb } = req.body;
    if(!courier || !awb) return res.status(400).json({ status: 400, message: 'courier and awb required' });
    if(!API_KEY) return res.status(500).json({ status: 500, message: 'Server API key not configured' });
    const url = `https://api.binderbyte.com/v1/track?api_key=${encodeURIComponent(API_KEY)}&courier=${encodeURIComponent(courier)}&awb=${encodeURIComponent(awb)}`;
    const r = await fetch(url);
    const data = await r.json();
    res.json(data);
  } catch(err) {
    console.error(err);
    res.status(500).json({ status:500, message: err.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Proxy server running on port', port));
