ResiTracker — Pro Final (Theme Switcher + Assets)
================================================

Konten:
- index.html            -> Halaman utama (static) dengan theme switcher, ekspedisi lengkap, dan UI profesional.
- assets/icons/*.svg    -> Ikon ekspedisi (placeholder SVG).
- backend/              -> Contoh proxy server (Node.js) untuk memanggil BinderByte API.
- .env.example          -> contoh konfigurasi environment.
- deploy_instructions.txt -> cara deploy ke GitHub Pages / Netlify dan konfigurasi API key.

Cara cepat:
1. Buka index.html di browser (static) untuk melihat tampilan.
2. Untuk hasil riil, jalankan backend dan set BINDERBYTE_API_KEY di .env, lalu ubah API_BASE di script index.html (kosong => simulasi).
